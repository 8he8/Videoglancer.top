"""
Flask application for Videoglancer - YouTube to PDF/PPT converter.
Extracted from the original Colab notebook and converted to a web application.
"""

import os
import sys
import shutil
import uuid
import logging
import json
import queue
import time

# ── Disable Python cache for real-time changes ────────────────────────────────
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
# ──────────────────────────────────────────────────────────────────────────────

# ── Verbose logging setup ─────────────────────────────────────────────────────
# Must happen before ANY other import so every logger inherits the handler.
os.environ.setdefault('PYTHONUNBUFFERED', '1')

_log_handler = logging.StreamHandler(sys.stdout)
_log_handler.setLevel(logging.DEBUG)
_log_handler.setFormatter(logging.Formatter(
    fmt='[%(levelname)s] %(name)s | %(message)s',
))

# Root logger — catches everything
_root = logging.getLogger()
_root.setLevel(logging.DEBUG)
_root.handlers.clear()
_root.addHandler(_log_handler)

# Per-library levels (keep noise down while keeping all app logs)
logging.getLogger('werkzeug').setLevel(logging.WARNING)      # HTTP requests (suppressed; we log our own)
logging.getLogger('yt_dlp').setLevel(logging.DEBUG)         # downloader
logging.getLogger('urllib3').setLevel(logging.INFO)         # HTTP pool (too noisy at DEBUG)
logging.getLogger('PIL').setLevel(logging.INFO)             # Pillow
logging.getLogger('googleapiclient').setLevel(logging.WARNING)
# ──────────────────────────────────────────────────────────────────────────────

from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, Response, stream_with_context
from werkzeug.utils import secure_filename
import threading
from utils.pipeline import process_main_url

logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 86400  # 24h cache for static assets (fonts, CSS, JS)

# Add zip to Jinja2 globals for template usage
app.jinja_env.globals.update(zip=zip)

# Job storage (in production, use a database)
jobs = {}
# Progress queues for SSE
progress_queues = {}
# Track current processing job (only one at a time)
current_processing_job_id = None

PROGRESS_STAGE_IDS = ('downloading', 'extracting', 'deduplicating', 'timestamps', 'compressing', 'building', 'autosave')


def _prefetch_early_meta(job_id, url, url_type):
    """Background thread: fetch video metadata ASAP for instant YouTube card on processing page.

    For singles: runs fetch_video_metadata(url) — a yt-dlp --dump-json --no-download call.
    For playlists: first extracts the playlist's video URLs, then fetches metadata
    for the first video. Runs in parallel with the page redirect, so if it finishes
    before the template renders, the duration/title are available on first paint.
    """
    try:
        from utils.youtube_downloader import fetch_video_metadata, get_playlist_videos

        target_url = url
        if url_type == 'playlist':
            urls, _ = get_playlist_videos(url)
            if not urls:
                return
            target_url = urls[0]

            # Push playlist total count early so frontend shows "1/X" immediately,
            # without waiting for the pipeline's own get_playlist_videos call to
            # finish and process through process_main_url.
            if job_id in jobs:
                jobs[job_id]['playlist_total'] = len(urls)
            if job_id in progress_queues:
                progress_queues[job_id].put({
                    'stage': 'playlist',
                    'message': f'Playlist: {len(urls)} videos',
                    'progress': 0,
                    'details': {},
                    'playlist_info': {
                        'total': len(urls),
                        'completed': 0,
                        'remaining': len(urls),
                    },
                    'stages': jobs[job_id].get('stages'),
                })

        meta, _, _ = fetch_video_metadata(target_url)
        if meta and job_id in jobs:
            jobs[job_id]['_early_meta'] = meta
            logger.info(
                f"[EARLY META] Prefetched for job {job_id}: "
                f"title={meta.get('title', '')!r}, duration={meta.get('duration')}"
            )
            # Push to SSE queue so the frontend receives video title + duration
            # immediately, without waiting for pipeline's full extraction.
            # The frontend's applyProgress() already handles details.video_info
            # regardless of stage — no frontend changes needed.
            if job_id in progress_queues:
                video_info = {
                    'title': meta.get('title', ''),
                    'thumbnail_url': meta.get('thumbnail_url', ''),
                    'duration': meta.get('duration'),
                    'url': jobs[job_id].get('url', ''),
                }
                progress_queues[job_id].put({
                    'stage': 'downloading',
                    'message': 'Video metadata loaded',
                    'progress': 0,
                    'details': {'video_info': video_info},
                    'playlist_info': {},
                    'stages': jobs[job_id].get('stages'),
                })
    except Exception as e:
        logger.warning(f"[EARLY META] Failed for job {job_id}: {e}")


def _initial_stages_state(deduplication_enabled=True, timestamp_enabled=True, compress_enabled=False, autosave_enabled=False):
    stages = {
        stage: {
            'status': 'pending',
            'progress': 0,
            'message': '',
            'details': {}
        }
        for stage in PROGRESS_STAGE_IDS
    }
    
    if not deduplication_enabled:
        stages['deduplicating']['status'] = 'skipped'
    if not timestamp_enabled:
        stages['timestamps']['status'] = 'skipped'
    if not compress_enabled:
        stages['compressing']['status'] = 'skipped'
    if not autosave_enabled:
        stages['autosave']['status'] = 'skipped'
    
    return stages


def _build_progress_payload(job_id):
    """Full progress snapshot for SSE / polling clients."""
    job = jobs.get(job_id, {})
    current = job.get('progress', {})
    return {
        'stage': current.get('stage', 'initializing'),
        'message': current.get('message', 'Starting…'),
        'progress': current.get('progress', 0),
        'details': current.get('details') or {},
        'playlist_info': current.get('playlist_info') or {},
        'stages': job.get('stages') or _initial_stages_state(
            job.get('deduplication_enabled', False),
            job.get('timestamp_enabled', True),
            job.get('compress_enabled', False),
            job.get('auto_save_enabled', False)
        ),
    }


def _sync_stage_states(job_id, stage, message, progress, details):
    """Keep per-step state so UI can render all steps in realtime."""
    if job_id not in jobs:
        return
    dedup = jobs[job_id].get('deduplication_enabled', False)
    ts = jobs[job_id].get('timestamp_enabled', True)
    comp = jobs[job_id].get('compress_enabled', False)
    auto = jobs[job_id].get('auto_save_enabled', False)
    stages = jobs[job_id].setdefault('stages', _initial_stages_state(dedup, ts, comp, auto))
    if stage not in PROGRESS_STAGE_IDS:
        return
    idx = PROGRESS_STAGE_IDS.index(stage)
    for i, sid in enumerate(PROGRESS_STAGE_IDS):
        if i < idx:
            stages[sid]['status'] = 'done'
            if stages[sid]['progress'] < 100:
                stages[sid]['progress'] = 100
        elif i == idx:
            if details and details.get('skipped'):
                stages[sid]['status'] = 'skipped'
            elif progress >= 100:
                stages[sid]['status'] = 'done'
                stages[sid]['message'] = 'Done'
            else:
                stages[sid]['status'] = 'active'
                stages[sid]['message'] = message
            stages[sid]['progress'] = max(stages[sid]['progress'], progress)
            stages[sid]['details'] = details or {}
        elif stages[sid]['status'] not in ('done', 'skipped'):
            stages[sid]['status'] = 'pending'

# Ensure directories exist and clean temp dirs at startup
from config import ensure_directories, IS_COLAB, is_drive_mounted, FRAMES_DIR, TEMP_DOWNLOAD_DIR
ensure_directories()

for d in [TEMP_DOWNLOAD_DIR, FRAMES_DIR]:
    if os.path.exists(d):
        shutil.rmtree(d)
    os.makedirs(d, exist_ok=True)
logger.info("Cleaned temp/downloads and temp/frames directories at startup")


@app.context_processor
def inject_globals():
    """Expose Colab flag, auto cache-busting, and notebook version to all templates."""
    static_folder = app.static_folder

    def static_url(filename):
        """Return a versioned static URL using file modification time for cache busting."""
        path = os.path.join(static_folder, filename)
        try:
            mtime = int(os.path.getmtime(path))
        except OSError:
            mtime = 0
        return url_for('static', filename=filename) + f'?v={mtime}'

    new_version_available = False
    latest_version = ''

    if IS_COLAB:
        # ── Colab: check marker file written by the notebook's own version check ──
        # The notebook compares its own NOTEBOOK_VERSION against the extracted
        # static/notebook-version.txt (from the latest zip), negating any need
        # for Flask to also fetch from GitHub directly.
        try:
            marker = '/content/notebook_update_available.txt'
            if os.path.exists(marker):
                with open(marker, 'r') as f:
                    mv = f.read().strip()
                if mv:
                    new_version_available = True
                    latest_version = mv
        except Exception:
            pass
    else:
        # ── Local: compare NOTEBOOK_VERSION (root) vs static/notebook-version.txt ───
        current_version = ''
        try:
            with open(os.path.join(app.root_path, 'NOTEBOOK_VERSION'), 'r') as f:
                current_version = f.read().strip()
        except OSError:
            current_version = ''

        if current_version:
            try:
                with open(os.path.join(static_folder, 'notebook-version.txt'), 'r') as f:
                    latest_version = f.read().strip()
            except OSError:
                latest_version = ''

            if latest_version and current_version != latest_version:
                new_version_available = True

    # Dev/testing override: ?test_notebook_banner=1 forces the banner on any page
    if not new_version_available and request.args.get('test_notebook_banner') == '1':
        new_version_available = True
        latest_version = latest_version or 'X.X'

    # Check if Google Drive is mounted (Colab only, checked at request time)
    drive_mounted = is_drive_mounted()

    # Compute dynamic UTM params from the request Host header
    utm = _get_utm_params()

    return {
        'is_colab': IS_COLAB,
        'drive_mounted': drive_mounted,
        'static_url': static_url,
        'new_version_available': new_version_available,
        'latest_version': latest_version,
        'utm_source': utm['utm_source'],
        'utm_medium': utm['utm_medium'],
    }


@app.before_request
def log_request_start():
    """Log incoming HTTP requests with full details."""
    logger.debug(f"{'─'*50}")
    logger.debug(f"[FRONTEND REQUEST] {request.method} {request.path}")
    logger.debug(f"Remote IP: {request.remote_addr}")
    logger.debug(f"Content-Type: {request.content_type}")
    logger.debug(f"User-Agent: {request.user_agent}")
    if request.method in ['POST', 'PUT', 'PATCH']:
        if request.form:
            logger.debug(f"Form Data:")
            for key, value in request.form.items():
                if 'password' not in key.lower():
                    logger.debug(f"  {key}: {value}")
                else:
                    logger.debug(f"  {key}: [REDACTED]")
    logger.debug(f"{'─'*50}")


@app.after_request
def log_request_end(response):
    """Log outgoing HTTP responses."""
    logger.debug(f"[FRONTEND RESPONSE] {request.method} {request.path} -> {response.status_code}")
    logger.debug(f"Content-Type: {response.content_type}")
    logger.debug(f"Content-Length: {response.content_length}")
    return response


@app.after_request
def add_cache_headers(response):
    """Set cache-control headers: no-cache for HTML, long cache for static assets."""
    if response.content_type and 'text/html' in response.content_type:
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
    return response


def _get_utm_params():
    """Return dict of UTM params for the header brand link.

    Detects the real hostname from request headers, checking proxy
    forwarding headers first (X-Forwarded-Host) before falling back
    to the Host header. This ensures tunnel/proxied requests use the
    original tunnel domain as utm_source, not the upstream address.

    For localhost/127.0.0.1: utm_source=local, utm_medium=direct.
    For tunnel domains (e.g., trycloudflare.com, bore.pub):
      utm_source = root domain only (e.g., 'trycloudflare.com')
      utm_medium = 'tunnel'

    For PDF/PPTX links in generated documents, use the output format as utm_source
    with utm_medium=document (handled in info_page_generator.py).
    """
    # Check proxy-forwarded host headers first (cloudflared sets Cf-Forwarded-Host,
    # other proxies use X-Forwarded-Host), then fall back to the Host header.
    host = (request.headers.get('X-Forwarded-Host') or
            request.headers.get('Cf-Forwarded-Host') or
            request.host)
    host = host.split(':')[0]  # strip port

    # Local development — includes tunnel upstream address (127.0.0.1)
    if host in ('127.0.0.1', 'localhost', '0.0.0.0'):
        logger.debug(f"[UTM] Detected local host={host!r}, returning utm_source=local")
        return {'utm_source': 'local', 'utm_medium': 'direct'}

    # Extract root domain (last 2 parts, e.g. 'trycloudflare.com' from 'abc-123.trycloudflare.com')
    parts = host.split('.')
    if len(parts) >= 2:
        root_domain = '.'.join(parts[-2:])
    else:
        root_domain = host

    logger.debug(f"[UTM] Detected host={host!r}, root_domain={root_domain!r}, returning utm_source={root_domain!r}")
    return {'utm_source': root_domain, 'utm_medium': 'tunnel'}


def _active_processing_job_id():
    """Return the job id currently processing, if any (only one at a time)."""
    global current_processing_job_id
    if current_processing_job_id and current_processing_job_id in jobs:
        if jobs[current_processing_job_id].get('status') == 'processing':
            return current_processing_job_id
    for jid, job in jobs.items():
        if job.get('status') == 'processing':
            current_processing_job_id = jid
            return jid
    current_processing_job_id = None
    return None


def _ensure_progress_queue(job_id):
    """Recreate SSE queue when user reopens the processing page (tunnel refresh)."""
    if job_id not in jobs:
        return False
    if job_id not in progress_queues:
        progress_queues[job_id] = queue.Queue()
    return True


@app.route('/')
def index():
    """Render the home page, or resume active processing."""
    active_id = _active_processing_job_id()
    if active_id:
        return redirect(url_for('processing', job_id=active_id))
    return render_template('index.html')


@app.route('/process', methods=['POST'])
def process():
    """Handle video processing request."""
    global current_processing_job_id
    
    try:
        active_id = _active_processing_job_id()
        if active_id:
            logger.info(f"[BACKEND] Job {active_id} is already processing, redirecting to it")
            return redirect(url_for('processing', job_id=active_id))
        
        # Get form data
        url = request.form.get('url', '').strip()
        quality = request.form.get('quality', '480p')
        output_format = request.form.get('output_format', 'pdf')
        extraction_method = request.form.get('extraction_method', 'Time Interval')
        time_interval = request.form.get('time_interval', '5.0')
        deduplication_enabled = request.form.get('deduplication') == 'on'
        # Scene Detection already captures distinct frames at scene changes — dedup would be redundant
        if extraction_method == 'Scene Detection':
            deduplication_enabled = False
        timestamp_enabled = request.form.get('timestamp') == 'on'
        auto_save_enabled = request.form.get('auto_save') == 'on'
        compress_enabled = request.form.get('compress') == 'on'
        compress_quality = int(request.form.get('compress_quality', 85))

        # Log all form parameters
        logger.info(f"{'─'*50}")
        logger.info("[BACKEND] VIDEO CONVERSION REQUEST RECEIVED")
        logger.info(f"{'─'*50}")
        logger.info(f"YouTube URL: {url}")
        logger.info(f"Quality: {quality}")
        logger.info(f"Output Format: {output_format}")
        logger.info(f"Extraction Method: {extraction_method}")
        logger.info(f"Time Interval: {time_interval}s")
        logger.info(f"Deduplication: {deduplication_enabled}")
        logger.info(f"Timestamp Overlay: {timestamp_enabled}")
        logger.info(f"Auto-save: {auto_save_enabled}")
        logger.info(f"Compress: {compress_enabled}")
        logger.info(f"{'─'*50}")

        # Validate URL
        if not url:
            return render_template('error.html', error='Please enter a YouTube URL')

        # Generate unique job ID
        job_id = str(uuid.uuid4())
        logger.info(f"[BACKEND] Generated Job ID: {job_id}")

        # Store job information
        jobs[job_id] = {
            'status': 'processing',
            'url': url,
            'quality': quality,
            'output_format': output_format,
            'extraction_method': extraction_method,
            'time_interval': time_interval,
            'deduplication_enabled': deduplication_enabled,
            'timestamp_enabled': timestamp_enabled,
            'auto_save_enabled': auto_save_enabled,
            'compress_enabled': compress_enabled,
            'compress_quality': compress_quality,
            'output_paths': [],
            'video_titles': [],
            'error': None,
            'start_time': time.time(),
            'processing_start_time': None,
            '_active_processing_total': 0.0,
            '_segment_start': None,
            'progress': {
                'stage': 'initializing',
                'message': 'Starting...',
                'progress': 0,
                'details': {},
                'playlist_info': {},
            },
            'stages': _initial_stages_state(deduplication_enabled, timestamp_enabled, compress_enabled, auto_save_enabled),
        }
        
        # Set as current processing job
        current_processing_job_id = job_id
        logger.info(f"[BACKEND] Set current processing job to: {job_id}")
        
        # Create progress queue for SSE
        progress_queues[job_id] = queue.Queue()

        # Detect single/playlist from URL alone (no yt-dlp call)
        from utils.youtube_downloader import parse_youtube_url
        url_type, url_id = parse_youtube_url(url)
        is_playlist = (url_type == 'playlist')

        jobs[job_id]['is_playlist'] = is_playlist
        jobs[job_id]['playlist_total'] = 0
        jobs[job_id]['_url_type'] = url_type
        jobs[job_id]['_video_id'] = url_id if url_type == 'single' else None

        # Start background metadata prefetch for instant YouTube card
        # (runs in parallel with page navigation — no effect on current pipeline logic)
        threading.Thread(
            target=_prefetch_early_meta,
            args=(job_id, url, url_type),
            daemon=True,
        ).start()

        thread = threading.Thread(
            target=process_job,
            args=(job_id, url, output_format, extraction_method,
                  time_interval, quality, deduplication_enabled, timestamp_enabled, auto_save_enabled, compress_enabled,
                  compress_quality)
        )
        thread.daemon = True
        thread.start()
        logger.info(f"[BACKEND] Started processing thread for job {job_id}")

        # Redirect to processing page
        return redirect(url_for('processing', job_id=job_id))

    except Exception as e:
        logger.error(f"[BACKEND ERROR] Error in process route: {e}", exc_info=True)
        return render_template('error.html', error=str(e))


def progress_callback(job_id, stage, message, progress=0, details=None, playlist_info=None):
    """Progress callback to update job progress and send to SSE queue.
    
    Timing: tracks active processing time starting from the first 'downloading'
    event (not job creation). For playlists, pauses between videos so only
    actual processing time is counted.
    """
    log_msg = f"[BACKEND PROGRESS] [{stage.upper()}] {message} ({progress}%)"
    if details:
        log_msg += f" | Details: {details}"
    if playlist_info:
        log_msg += f" | Playlist: {playlist_info}"
    logger.info(log_msg)
    
    if job_id in jobs:
        prev_pl = jobs[job_id]['progress'].get('playlist_info') or {}

        # ── Active processing time tracking ──
        # Start timer on first 'downloading' event (not job creation)
        if stage == 'downloading' and jobs[job_id].get('processing_start_time') is None:
            jobs[job_id]['processing_start_time'] = time.time()
            jobs[job_id]['_segment_start'] = time.time()
            logger.info(f"[TIMER] Started processing timer for job {job_id}")
        # Resume after a playlist pause (next video's download starts)
        elif stage == 'downloading' and jobs[job_id].get('_segment_start') is None:
            jobs[job_id]['_segment_start'] = time.time()
            logger.info(f"[TIMER] Resumed processing timer for job {job_id}")

        # When switching to a new playlist video, pause timing
        # (the gap between videos is not counted as active processing)
        if stage == 'playlist' and playlist_info:
            new_completed = playlist_info.get('completed', 0)
            old_completed = prev_pl.get('completed', 0)
            if new_completed != old_completed:
                # Pause timing: add elapsed segment to accumulated total
                seg_start = jobs[job_id].get('_segment_start')
                if seg_start is not None:
                    elapsed = time.time() - seg_start
                    jobs[job_id]['_active_processing_total'] += elapsed
                    jobs[job_id]['_segment_start'] = None
                    logger.info(f"[TIMER] Paused — video segment completed ({elapsed:.1f}s)")

                dedup = jobs[job_id].get('deduplication_enabled', False)
                ts = jobs[job_id].get('timestamp_enabled', True)
                comp = jobs[job_id].get('compress_enabled', False)
                auto = jobs[job_id].get('auto_save_enabled', False)
                jobs[job_id]['stages'] = _initial_stages_state(dedup, ts, comp, auto)

        new_details = details or {}

        jobs[job_id]['progress'] = {
            'stage': stage,
            'message': message,
            'progress': progress,
            'details': new_details,
            'playlist_info': playlist_info if playlist_info else prev_pl,
        }
        if stage == 'complete' and job_id in jobs:
            for sid in PROGRESS_STAGE_IDS:
                jobs[job_id]['stages'][sid]['status'] = 'done'
                if jobs[job_id]['stages'][sid]['progress'] < 100:
                    jobs[job_id]['stages'][sid]['progress'] = 100
                jobs[job_id]['stages'][sid]['message'] = 'Done'
        elif stage == 'playlist':
            if playlist_info and job_id in jobs:
                jobs[job_id]['progress']['playlist_info'] = playlist_info
        elif stage in PROGRESS_STAGE_IDS:
            _sync_stage_states(job_id, stage, message, progress, details)

    if job_id in progress_queues:
        try:
            progress_queues[job_id].put(_build_progress_payload(job_id))
        except Exception:
            pass

def process_job(job_id, url, output_format, extraction_method, time_interval,
                quality, deduplication_enabled, timestamp_enabled,
                auto_save_enabled, compress_enabled=False, compress_quality=85):
    """Process video in background thread."""
    global current_processing_job_id

    try:
        # Check if job was cancelled before processing started
        if job_id in jobs and jobs[job_id].get('cancelled', False):
            logger.info(f"Job {job_id} was cancelled before processing started")
            return

        # Get URL type from job dict (set by route handler via URL parsing)
        url_type = jobs.get(job_id, {}).get('_url_type', None)

        output_paths, video_titles, error = process_main_url(
            url, output_format, extraction_method, time_interval, quality,
            job_id, deduplication_enabled, timestamp_enabled, compress_enabled,
            compress_quality=compress_quality,
            progress_callback=lambda stage, message, progress, details=None, playlist_info=None:
                progress_callback(job_id, stage, message, progress, details, playlist_info),
            url_type=url_type,
        )

        # Check if job was cancelled during processing
        if job_id in jobs and jobs[job_id].get('cancelled', False):
            logger.info(f"Job {job_id} was cancelled during processing")
            progress_callback(job_id, 'cancelled', 'Processing cancelled by user', 0)
            return

        if error:
            if error == "Processing cancelled by user" or jobs[job_id].get('cancelled'):
                jobs[job_id]['status'] = 'cancelled'
                progress_callback(job_id, 'cancelled', 'Processing cancelled by user', 0)
            else:
                jobs[job_id]['status'] = 'failed'
                jobs[job_id]['error'] = error
                # Emergency-save ALL output files to Google Drive before the
                # Colab runtime potentially disconnects (bot detection kills the
                # VM — this ensures previously converted files survive the restart).
                saved_count = 0
                if IS_COLAB:
                    saved_count = emergency_save_all_to_drive()
                jobs[job_id]['saved_files_count'] = saved_count
                progress_callback(job_id, 'error', f'Failed: {error}', 0)
        else:
            jobs[job_id]['status'] = 'completed'
            jobs[job_id]['output_paths'] = output_paths
            jobs[job_id]['video_titles'] = video_titles
            # Calculate processing duration from active segments (excludes gaps between playlist videos)
            total = jobs[job_id].get('_active_processing_total', 0.0)
            seg_start = jobs[job_id].get('_segment_start')
            if seg_start is not None:
                total += time.time() - seg_start
            jobs[job_id]['processing_duration'] = total
            
            # Auto-save to Google Drive if enabled (fire BEFORE 'complete' so SSE delivers it)
            if auto_save_enabled:
                try:
                    auto_save_to_google_drive(job_id, output_paths)
                    progress_callback(job_id, 'autosave', 'Auto-saved to Google Drive', 100)
                except Exception as e:
                    logger.warning(f"Auto-save to Google Drive failed: {e}")

            progress_callback(job_id, 'complete', 'Processing complete!', 100)

    except Exception as e:
        logger.error(f"Error processing job {job_id}: {e}")
        # Check if error is due to cancellation
        if job_id in jobs and jobs[job_id].get('cancelled', False):
            logger.info(f"Job {job_id} processing interrupted due to cancellation")
            progress_callback(job_id, 'cancelled', 'Processing cancelled by user', 0)
        else:
            jobs[job_id]['status'] = 'failed'
            jobs[job_id]['error'] = str(e)
            progress_callback(job_id, 'error', f'Error: {str(e)}', 0)
    finally:
        # Safety-net: clean up any leftover temp directories for this job
        try:
            from utils.file_manager import cleanup_job_directories
            cleanup_job_directories(job_id)
        except Exception:
            pass

        # Clear current processing job when done
        if current_processing_job_id == job_id:
            current_processing_job_id = None
            logger.info(f"Job {job_id} processing completed, cleared current_processing_job_id")


@app.route('/processing')
def processing_active():
    """Resume the single active processing job (localhost or Cloudflare tunnel)."""
    active_id = _active_processing_job_id()
    if active_id:
        return redirect(url_for('processing', job_id=active_id))
    return redirect(url_for('index'))


@app.route('/processing/<job_id>')
def processing(job_id):
    """Show processing status page."""
    active_id = _active_processing_job_id()

    if job_id not in jobs:
        if active_id:
            return redirect(url_for('processing', job_id=active_id))
        return render_template('error.html', error='Invalid job ID')

    job = jobs[job_id]
    if job.get('status') == 'processing' and active_id and active_id != job_id:
        return redirect(url_for('processing', job_id=active_id))

    if job.get('status') == 'processing':
        _ensure_progress_queue(job_id)

    is_playlist = job.get('is_playlist', False)
    early_video_info = None
    video_id = job.get('_video_id')
    early_meta = job.get('_early_meta')

    if video_id:
        early_video_info = {
            'thumbnail_url': (
                early_meta.get('thumbnail_url')
                if early_meta
                else f'https://img.youtube.com/vi/{video_id}/hqdefault.jpg'
            ),
            'title': early_meta.get('title', '') if early_meta else '',
            'duration': early_meta.get('duration') if early_meta else None,
            'url': job.get('url', ''),
        }
    elif early_meta:
        # Playlist with prefetched first-video metadata
        early_video_info = {
            'thumbnail_url': early_meta.get('thumbnail_url', ''),
            'title': early_meta.get('title', ''),
            'duration': early_meta.get('duration'),
            'url': job.get('url', ''),
        }

    # Force initial_progress stage to 'initializing' so the "Starting..."
    # overlay is always visible on first paint, regardless of how far the
    # backend thread has progressed by the time the page renders.
    # The real backend state arrives via SSE/poll within ~1.5s.
    init_progress = _build_progress_payload(job_id)
    init_progress['stage'] = 'initializing'
    init_progress['message'] = 'Starting...'
    init_progress['progress'] = 0

    return render_template(
        'processing.html',
        job_id=job_id,
        is_playlist=is_playlist,
        playlist_total=job.get('playlist_total', 0) if is_playlist else 0,
        deduplication_enabled=bool(job.get('deduplication_enabled', False)),
        timestamp_enabled=bool(job.get('timestamp_enabled', True)),
        compress_enabled=bool(job.get('compress_enabled', False)),
        compress_quality=job.get('compress_quality', 85),
        autosave_enabled=bool(job.get('auto_save_enabled', False)),
        initial_progress=init_progress,
        start_time=job.get('start_time', time.time()),
        early_video_info=early_video_info,
    )


@app.route('/status/<job_id>')
def status(job_id):
    """Return job status as JSON."""
    if job_id not in jobs:
        return jsonify({'error': 'Invalid job ID'}), 404
    
    job = jobs[job_id]
    return jsonify({
        'status': job['status'],
        'error': job.get('error'),
        'deduplication_enabled': bool(job.get('deduplication_enabled', False)),
        'is_playlist': bool(job.get('is_playlist', False)),
        'output_paths': job.get('output_paths', []),
        'video_titles': job.get('video_titles', []),
        'processing_duration': job.get('processing_duration'),
        'progress': _build_progress_payload(job_id),
    })


@app.route('/progress/<job_id>')
def progress(job_id):
    """SSE endpoint for real-time progress updates."""
    if job_id not in jobs:
        return jsonify({'error': 'Invalid job ID'}), 404
    if job_id not in progress_queues:
        if jobs[job_id].get('status') != 'processing':
            return jsonify({'error': 'Job not processing'}), 404
        progress_queues[job_id] = queue.Queue()
    
    def event_stream():
        try:
            while job_id in progress_queues:
                try:
                    progress_data = progress_queues[job_id].get(timeout=1)
                    yield f"data: {json.dumps(progress_data)}\n\n"

                    if progress_data.get('stage') in ('complete', 'error'):
                        break
                except queue.Empty:
                    yield ": keepalive\n\n"
        except GeneratorExit:
            pass
        finally:
            # Keep queue while job is still processing so tunnel/page refresh can reconnect
            if job_id in jobs and jobs[job_id].get('status') != 'processing':
                progress_queues.pop(job_id, None)
    
    return Response(
        stream_with_context(event_stream()),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache, no-transform',
            'X-Accel-Buffering': 'no',
            'Connection': 'keep-alive',
        },
    )


@app.route('/result/<job_id>')
def result(job_id):
    """Show result page with download links."""
    if job_id in jobs:
        job = jobs[job_id]
        if job['status'] != 'completed':
            return redirect(url_for('processing', job_id=job_id))
    
    processing_duration = None
    if job_id in jobs:
        job = jobs[job_id]
        if job.get('processing_duration') is not None:
            processing_duration = round(job['processing_duration'], 1)
    return render_template('result.html',
                         job_id=job_id,
                         output_paths=[],
                         video_titles=[],
                         processing_duration=processing_duration)


@app.route('/downloads/videoglancer-top.zip')
def download_colab_zip():
    """Serve the latest distribution zip for Colab auto-download."""
    import glob as _glob
    dist_dir = os.path.join(os.path.dirname(__file__), 'dist')
    zips = sorted(_glob.glob(os.path.join(dist_dir, 'videoglancer-top.zip')))
    if not zips:
        return 'No distribution zip found. Run build.py first.', 404
    latest = zips[-1]
    return send_file(latest, as_attachment=True, download_name='videoglancer-top.zip')


@app.route('/download/<path:filename>')
def download(filename):
    """Download generated file. Supports files in OUTPUT_DIR directly or
    in subdirectories (e.g., playlist folders).
    PDFs are served inline (opens in browser), PPTX/ZIP force download."""
    from config import OUTPUT_DIR
    from utils.file_manager import find_output_file

    _, file_path = find_output_file(None, filename)
    if not file_path:
        file_path = os.path.join(OUTPUT_DIR, filename)

    if not os.path.exists(file_path):
        return render_template('error.html', error='File not found')

    # Serve PDFs inline so browser opens them in a new tab; other files force download
    ext = os.path.splitext(filename)[1].lower()
    as_attachment = ext != '.pdf'

    download_name = os.path.basename(filename)
    return send_file(file_path, as_attachment=as_attachment, download_name=download_name)


@app.route('/cancel/<job_id>', methods=['GET', 'POST'])
def cancel(job_id):
    """Cancel a processing job."""
    global current_processing_job_id
    
    if job_id not in jobs:
        return jsonify({'success': False, 'message': 'Job not found'}), 404
    
    job = jobs[job_id]
    
    if job['status'] != 'processing':
        return jsonify({'success': False, 'message': 'Job is not currently processing'}), 400
    
    from utils.job_runtime import mark_cancelled

    job['status'] = 'cancelled'
    job['cancelled'] = True
    mark_cancelled(job_id)
    progress_callback(job_id, 'cancelled', 'Processing cancelled by user', 0)

    if current_processing_job_id == job_id:
        current_processing_job_id = None

    logger.info(f"Job {job_id} cancelled by user")

    return jsonify({'success': True, 'message': 'Processing cancelled'})


@app.route('/api/files')
def list_files():
    """List output files directly from OUTPUT_DIR (flat structure)."""
    files = []
    jobs_meta = {}
    filter_job_id = request.args.get('job_id', '').strip()

    from config import OUTPUT_DIR
    from utils.file_manager import load_output_meta, iter_output_files, ZIP_SUFFIX

    # Build lookup of filenames belonging to each job
    title_lookup = {}
    job_output_basenames = set()  # files belonging to the filtered job
    for jid, job in jobs.items():
        paths = job.get('output_paths', [])
        titles = job.get('video_titles', [])
        for path, title in zip(paths, titles):
            base = os.path.basename(path)
            title_lookup[base] = title
            if filter_job_id and jid == filter_job_id:
                job_output_basenames.add(base)

    # If filtering and no in-memory results, build set from persisted metadata
    if filter_job_id and not job_output_basenames:
        disk_meta = load_output_meta(OUTPUT_DIR)
        for fname, meta_entry in disk_meta.items():
            saved_job_id = meta_entry.get('job_id', '')
            # Match exact or playlist sub-job (e.g. "abc_video_1", "abc_video_2")
            if saved_job_id == filter_job_id or saved_job_id.startswith(filter_job_id + '_video_'):
                job_output_basenames.add(fname)

    for storage_id, job_path, filename, filepath in iter_output_files():
        meta_key = os.path.basename(filename)

        # If filtering by job, skip files not produced by this job
        if filter_job_id and meta_key not in job_output_basenames:
            continue

        disk_meta = load_output_meta(job_path)
        meta = disk_meta.get(meta_key, {})
        download_root = filter_job_id or 'outputs'
        subdir = os.path.dirname(filename) or None
        files.append({
            'job_id': download_root,
            'storage_job_id': storage_id,
            'filename': filename,
            'subdirectory': subdir,
            'download_url': url_for(
                'download', filename=filename
            ),
            'size': os.path.getsize(filepath),
            'created': os.path.getctime(filepath),
            'video_title': meta.get('video_title') or title_lookup.get(meta_key),
            'is_playlist_part': False,
        })

    # Look for zip files directly in OUTPUT_DIR (always scan, regardless of filter)
    zip_info = {}
    for filename in os.listdir(OUTPUT_DIR):
        if filename.startswith('Videoglancer all converted files -- '):
            zip_info = {
                'zip_filename': filename,
                'zip_download_url': url_for(
                    'download', filename=filename
                ),
            }
            break

    if zip_info:
        if filter_job_id:
            jobs_meta[filter_job_id] = zip_info
        else:
            jobs_meta['_global'] = zip_info

    files.sort(key=lambda x: x['created'], reverse=True)
    is_playlist = bool(filter_job_id and filter_job_id in jobs and jobs[filter_job_id].get('is_playlist', False))

    # Collect processing durations per job (including sub-jobs for playlists)
    durations = {}
    for jid, j in jobs.items():
        d = j.get('processing_duration')
        if d is not None:
            durations[jid] = d
            # Also set for any playlist sub-jobs (uuid_video_1, etc.)
            prefix = jid + '_video_'
            for sub_jid in jobs:
                if sub_jid.startswith(prefix):
                    durations[sub_jid] = d

    return jsonify({
        'files': files,
        'jobs': jobs_meta,
        'is_playlist': is_playlist,
        'playlist_total': jobs.get(filter_job_id, {}).get('playlist_total', 0) if filter_job_id else 0,
        'processing_durations': durations,
    })


@app.route('/save-all-to-drive/<job_id>', methods=['POST'])
def save_all_to_drive(job_id):
    """Save all output files for a job to Google Drive (Colab only)."""
    from utils.file_manager import iter_output_files

    saved = 0
    errors = []
    seen = set()
    for storage_id, _job_path, filename, _filepath in iter_output_files(job_id):
        key = (storage_id, filename)
        if key in seen:
            continue
        seen.add(key)
        success, message = save_file_to_google_drive(storage_id, filename)
        if success:
            saved += 1
        else:
            errors.append(message)

    if saved == 0:
        return jsonify({
            'success': False,
            'message': errors[0] if errors else 'No files to save',
        }), 400

    msg = f'Saved {saved} file(s) to Google Drive'
    if errors:
        msg += f' ({len(errors)} failed)'
    return jsonify({'success': True, 'message': msg, 'saved_count': saved})


@app.route('/save-to-drive/<job_id>/<filename>')
def save_to_drive(job_id, filename):
    """Save a specific file to Google Drive."""
    success, message = save_file_to_google_drive(job_id, filename)
    if success:
        return jsonify({'success': True, 'message': message})
    else:
        return jsonify({'success': False, 'message': message}), 400


@app.route('/create-zip/<job_id>')
def create_zip(job_id):
    """Create a zip of all output files directly in OUTPUT_DIR. Replaces any prior zip."""
    try:
        import zipfile
        import datetime
        from config import OUTPUT_DIR
        from utils.file_manager import iter_output_files, ZIP_SUFFIX

        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        zip_filename = f"{ZIP_SUFFIX}{timestamp}.zip"
        zip_path = os.path.join(OUTPUT_DIR, zip_filename)

        # Remove any existing zip
        for existing in os.listdir(OUTPUT_DIR):
            if existing.startswith('Videoglancer all converted files -- '):
                try:
                    os.remove(os.path.join(OUTPUT_DIR, existing))
                except OSError:
                    pass

        file_count = 0
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for storage_id, _job_path, filename, file_path in iter_output_files(job_id):
                zipf.write(file_path, filename)
                file_count += 1

        if file_count == 0:
            return jsonify({'success': False, 'message': 'No files to zip'}), 400

        logger.info(f"Created zip file: {zip_filename} ({file_count} files)")
        return jsonify({'success': True, 'zip_filename': zip_filename, 'file_count': file_count})

    except Exception as e:
        logger.error(f"Error creating zip: {e}")
        return jsonify({'success': False, 'message': f'Failed to create zip: {str(e)}'}), 500


def auto_save_to_google_drive(job_id, output_paths):
    """Copy output files from local OUTPUT_DIR to Google Drive if in Colab with Drive mounted."""
    try:
        if IS_COLAB:
            from config import DRIVE_DIR
            if not os.path.isdir('/content/drive/MyDrive'):
                logger.warning("Google Drive is not mounted — skipping auto-save")
                return
            import shutil
            os.makedirs(DRIVE_DIR, exist_ok=True)
            for src in (output_paths or []):
                if os.path.exists(src):
                    dst = os.path.join(DRIVE_DIR, os.path.basename(src))
                    shutil.copy2(src, dst)
                    logger.info(f"Auto-saved to Drive: {os.path.basename(src)}")
    except Exception as e:
        logger.warning(f"Auto-save to Drive failed: {e}")


def emergency_save_all_to_drive():
    """Copy ALL output files from local OUTPUT_DIR to Google Drive.
    Returns the number of files copied."""
    if not IS_COLAB:
        return 0
    try:
        from config import OUTPUT_DIR, DRIVE_DIR
        import shutil
        os.makedirs(DRIVE_DIR, exist_ok=True)

        saved = 0
        for entry in os.listdir(OUTPUT_DIR):
            src = os.path.join(OUTPUT_DIR, entry)
            if not os.path.isfile(src):
                continue
            if entry == 'outputs_meta.json':
                continue
            dst = os.path.join(DRIVE_DIR, entry)
            shutil.copy2(src, dst)
            saved += 1
            logger.info(f"Emergency saved to Drive: {entry}")

        logger.info(f"Emergency save: {saved} file(s) copied to Google Drive")
        return saved
    except Exception as e:
        logger.warning(f"Emergency file save failed: {e}")
        return 0


def save_file_to_google_drive(job_id, filename):
    """Copy a specific file from local OUTPUT_DIR to Google Drive."""
    try:
        if IS_COLAB:
            from config import OUTPUT_DIR, DRIVE_DIR
            if not os.path.isdir('/content/drive/MyDrive'):
                return False, "Google Drive is not mounted. Run the Drive mount cell in Colab first."
            import shutil
            os.makedirs(DRIVE_DIR, exist_ok=True)

            file_path = os.path.join(OUTPUT_DIR, filename)
            if not os.path.exists(file_path):
                from utils.file_manager import find_output_file
                _storage_id, file_path = find_output_file(job_id, filename)

            if file_path and os.path.exists(file_path):
                dst = os.path.join(DRIVE_DIR, filename)
                shutil.copy2(file_path, dst)
                logger.info(f"Saved to Drive: {filename}")
                return True, f"Saved to Google Drive: {filename}"
            else:
                return False, f"File {filename} not found"
        else:
            return False, "Google Drive save is only available in Google Colab"
    except Exception as e:
        logger.warning(f"Save to Google Drive failed: {e}")
        return False, f"Failed to save to Google Drive: {str(e)}"


@app.route('/error')
def error_page():
    """Show error message from query string."""
    error_msg = request.args.get('error', 'An error occurred')
    job_id = request.args.get('job_id', '').strip()
    saved_files_count = 0
    if job_id and job_id in jobs:
        saved_files_count = jobs[job_id].get('saved_files_count', 0)
    return render_template(
        'error.html', error=error_msg,
        saved_files_count=saved_files_count, is_colab=IS_COLAB
    )


@app.route('/cancelled')
def cancelled_page():
    """Show cancellation confirmation page."""
    return render_template('cancelled.html')


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return render_template('error.html', error='Page not found', saved_files_count=0), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    logger.error(f"Internal server error: {error}")
    return render_template('error.html', error='Internal server error', saved_files_count=0), 500


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))

    logger.info("")
    logger.info("─" * 50)
    logger.info("VIDEOGLANCER — starting")
    if not IS_COLAB:
        logger.info(f"Local  : http://127.0.0.1:{port}")
        logger.info(f"Network: http://0.0.0.0:{port}")
    logger.info(f"Colab  : {IS_COLAB}")
    logger.info("All HTTP requests and backend processing are logged below.")
    logger.info("─" * 50)
    logger.info("")

    # use_reloader=True auto-restarts on Python file changes (dev convenience).
    # Set FLASK_DEBUG=0 to disable the interactive debugger.
    # Set FLASK_USE_RELOADER=0 to disable the auto-reloader (Colab).
    debug_mode = os.environ.get('FLASK_DEBUG', 'true').lower() not in ('false', '0')
    use_reloader = os.environ.get('FLASK_USE_RELOADER', 'true').lower() not in ('false', '0')
    app.run(host='0.0.0.0', port=port, debug=debug_mode, use_reloader=use_reloader)
