"""
Main processing pipeline orchestrator.
Extracted from the original Colab notebook.
"""

import os
import re
import datetime
import threading
import logging
from .youtube_downloader import download_video_file, get_playlist_videos, format_youtube_time, parse_youtube_url, fetch_oembed_metadata
from .frame_extractor import extract_frames_time_interval, extract_frames_scene_detection
from .deduplicator import deduplicate_frames_intelligent
from .timestamp_overlay import apply_timestamps_to_frames
from .pdf_generator import convert_frames_to_pdf
from .ppt_generator import convert_frames_to_ppt
from .file_manager import setup_job_directories, cleanup_job_directories, save_output_meta
from .job_runtime import is_cancelled

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ── Prefetch cache for playlist metadata ─────────────────────────────────
# Cache stores (simple_meta, full_info, working_clients) per URL.
# Populated by background threads before the video is reached in the loop.
_prefetch_cache = {}
_prefetch_lock = threading.Lock()


def process_video(url, output_format, extraction_method, time_interval, quality,
                  job_id, deduplication_enabled=True, timestamp_enabled=False, compress_enabled=False,
                  compress_quality=85,
                  progress_callback=None, target_output_dir=None,
                  prefetched_metadata=None):
    """
    Main function to process video with info page, timestamps, and deduplication.
    
    Args:
        url: YouTube video URL
        output_format: Either 'pdf' or 'pptx'
        extraction_method: Either 'Scene Detection' or 'Time Interval'
        time_interval: Time interval in seconds (for Time Interval method)
        quality: Video quality (e.g., '480p')
        job_id: Unique job identifier
        deduplication_enabled: Whether to enable frame deduplication
        timestamp_enabled: Whether to add timestamps to frames
        compress_enabled: Whether to re-compress frames before building output
        compress_quality: JPEG quality for compression (1-100, higher = better)
        progress_callback: Optional callback function to report progress (stage, message, progress)
    
    Returns:
        Tuple of (output_path, video_title, error_message) or (None, None, error_message) on failure
    """
    
    def update_progress(stage, message, progress=0, details=None, playlist_info=None):
        """Helper function to update progress via callback.
        Progress is logged by app.py's progress_callback, so no duplicate log here."""
        if progress_callback:
            progress_callback(stage, message, progress, details, playlist_info)

    def cancelled():
        # For playlist videos, sub_job_id is like "{parent}_video_{i}".
        # We need to check BOTH the sub-job AND the parent job so that
        # cancelling the main job instantly stops all sub-videos.
        parent_id = job_id.rsplit('_video_', 1)[0] if '_video_' in job_id else job_id
        return is_cancelled(job_id) or is_cancelled(parent_id)

    from config import CONCURRENT_DOWNLOADS, ffmpeg_available

    if cancelled():
        return None, None, "Processing cancelled by user"

    # Setup job directories
    job_output_dir, job_frames_dir, job_temp_dir = setup_job_directories(job_id)
    if target_output_dir:
        job_output_dir = target_output_dir
        os.makedirs(target_output_dir, exist_ok=True)
    
    logger.info(f"\n▶️ Processing URL: {url}\n")

    try:
        if cancelled():
            return None, None, "Processing cancelled by user"

        # ── Instant card render via oEmbed (~200ms) ──────────────────────────
        # Always call oEmbed first — for both single and playlist videos.
        # This puts the YouTube card (title + thumbnail) on screen almost
        # instantly while the full yt-dlp extraction runs in parallel.
        # If oEmbed fails, the early_metadata_callback from download_video_file
        # will fill in the card when yt-dlp's internal extraction completes.
        _early_meta_sent = [False]
        def _on_early_metadata(info_dict):
            """Called from download_video_file when yt-dlp extracts metadata."""
            if _early_meta_sent[0]:
                return
            _early_meta_sent[0] = True
            video_info = {
                'title': info_dict.get('title', ''),
                'thumbnail_url': info_dict.get('thumbnail', info_dict.get('thumbnail_url', '')),
                'duration': info_dict.get('duration'),
                'url': url,
            }
            update_progress('downloading', 'Starting video download...', 0, {
                'video_info': video_info,
                'downloaded': 0,
                'total': 0,
            })

        oembed_data = fetch_oembed_metadata(url)
        if oembed_data:
            update_progress('downloading', 'Starting video download...', 0, {
                'video_info': {
                    'title': oembed_data.get('title', ''),
                    'thumbnail_url': oembed_data.get('thumbnail_url', ''),
                    'url': url,
                },
                'downloaded': 0,
                'total': 0,
            })
        else:
            update_progress('downloading', 'Starting video download...', 0, {'downloaded': 0, 'total': 0})

        # ── Download optimization via prefetched metadata (playlist only) ──
        # If this is a playlist video, the background prefetch thread already
        # extracted the full yt-dlp info dict. Pass it to download_video_file
        # to skip its own redundant web extraction (~5-10s saved).
        prefetched_info = None
        prefetched_clients = None
        if prefetched_metadata is not None:
            meta, full_info, working_clients = prefetched_metadata
            prefetched_info = full_info
            prefetched_clients = working_clients
            # Fallback: use prefetched metadata for card if oEmbed failed
            if not oembed_data and meta:
                _early_meta_sent[0] = True
                update_progress('downloading', 'Starting video download...', 0, {
                    'video_info': {
                        'title': meta.get('title', ''),
                        'thumbnail_url': meta.get('thumbnail_url', ''),
                        'duration': meta.get('duration'),
                        'url': url,
                    },
                    'downloaded': 0,
                    'total': 0,
                })

        # Step 1: Start download immediately — no separate metadata fetch.
        # The download function extracts metadata internally and pipes it back
        # via early_metadata_callback for the YouTube preview card.
        logger.info("\n" + "=" * 70 + "\nDOWNLOADING VIDEO\n" + "=" * 70)

        # Capture final download size for the 'Video download complete' message
        _last_dl = [0, 0]
        def _on_download_progress(d, t, speed=None, actual_height=None):
            _last_dl[0], _last_dl[1] = d, t
            # When total is unknown (0), show 0% progress rather than jumping to 100%
            if t <= 0:
                pct = 0
            else:
                pct = min(100, int((d / t) * 100))
            details = {'downloaded': d, 'total': t}
            if speed:
                details['speed'] = speed
            # Show the actual resolution being downloaded (detected from format),
            # not the user-selected quality. Fall back to user selection if unknown.
            display_quality = f"{actual_height}p" if actual_height else quality
            update_progress(
                'downloading',
                f'Downloading video at {display_quality}...',
                pct,
                details,
            )

        (local_download_file, video_title, actual_height, duration, fps,
         thumbnail_url, video_url) = download_video_file(
            url, quality, job_temp_dir, noplaylist_flag=True, concurrent_downloads=CONCURRENT_DOWNLOADS,
            progress_callback=_on_download_progress,
            cancel_check=cancelled,
            prefetched_info=prefetched_info,
            prefetched_clients=prefetched_clients,
            early_metadata_callback=_on_early_metadata if not _early_meta_sent[0] else None,
        )

        # Use actual downloaded resolution for info page display
        if isinstance(actual_height, (int, float)):
            actual_quality = f"{int(actual_height)}p"
        else:
            actual_quality = None

        if cancelled():
            cleanup_job_directories(job_id)
            return None, None, "Processing cancelled by user"

        if not local_download_file:
            error_msg = "Failed to download video"
            logger.error(error_msg)
            update_progress('error', error_msg, 0)
            return None, None, error_msg

        video_info = {
            'title': video_title,
            'thumbnail_url': thumbnail_url,
            'duration': duration,
            'url': video_url,
        }
        update_progress('downloading', 'Video download complete', 100, {
            'downloaded': _last_dl[0],
            'total': _last_dl[1],
            'video_info': video_info,
        })

        if cancelled():
            cleanup_job_directories(job_id)
            return None, None, "Processing cancelled by user"

        if not ffmpeg_available():
            error_msg = (
                "FFmpeg is not installed. Install FFmpeg and add it to PATH, "
                "then restart the app (Windows: winget install Gyan.FFmpeg)."
            )
            logger.error(error_msg)
            update_progress('error', error_msg, 0)
            cleanup_job_directories(job_id)
            return None, None, error_msg

        # Best JPEG quality for frame extraction (1 = best, scale 1-31)
        frame_quality = 1

        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        safe_video_title = re.sub(r'[^a-zA-Z0-9 -]', '', video_title)
        output_filename_base = f"{safe_video_title} -- {timestamp}.{output_format}"

        estimated_frames = max(1, int(duration / float(time_interval))) if extraction_method != "Scene Detection" else max(1, int(duration / 2))

        method_tag = "SD method" if extraction_method == "Scene Detection" else "TI method"

        def on_extract_progress(count, total_est, pct):
            update_progress(
                'extracting',
                f'Extracting frames by {method_tag}...',
                pct,
                {'frames_extracted': count, 'total_frames': total_est or estimated_frames},
            )

        # Frame extraction
        update_progress('extracting', 'Starting frame extraction...', 0, {'frames_extracted': 0, 'total_frames': estimated_frames})
        extracted_frames_paths = []
        extracted_pts_times = None  # exact PTS timestamps (Scene Detection only)
        if extraction_method == "Scene Detection":
            extracted_frames_paths, extracted_pts_times = extract_frames_scene_detection(
                local_download_file, job_frames_dir,
                duration=duration, fps=fps, frame_quality=frame_quality,
                progress_callback=on_extract_progress,
                job_id=job_id,
            )
        else:
            extracted_frames_paths = extract_frames_time_interval(
                local_download_file, job_frames_dir,
                time_interval, duration=duration, fps=fps,
                frame_quality=frame_quality,
                progress_callback=on_extract_progress,
                job_id=job_id,
            )

        if cancelled():
            cleanup_job_directories(job_id)
            return None, None, "Processing cancelled by user"

        if not extracted_frames_paths:
            if not ffmpeg_available():
                error_msg = (
                    "FFmpeg is not installed. Install FFmpeg and add it to PATH, "
                    "then restart the app (Windows: winget install Gyan.FFmpeg)."
                )
            else:
                error_msg = "No frames extracted"
            logger.error(error_msg)
            update_progress('error', error_msg, 0)
            cleanup_job_directories(job_id)
            return None, None, error_msg

        update_progress('extracting', f'Extracted {len(extracted_frames_paths)} frames', 100, {'frames_extracted': len(extracted_frames_paths), 'total_frames': len(extracted_frames_paths)})

        # Clean up downloaded video file — no longer needed after frame extraction
        if local_download_file and os.path.exists(local_download_file):
            try:
                os.remove(local_download_file)
                logger.info(f"Cleaned up downloaded video: {local_download_file}")
            except Exception as e:
                logger.warning(f"Failed to clean up downloaded video: {e}")

        if cancelled():
            cleanup_job_directories(job_id)
            return None, None, "Processing cancelled by user"

        # Deduplication
        cleaned_frames_paths = extracted_frames_paths
        if deduplication_enabled:
            total_frames = len(extracted_frames_paths)
            update_progress('deduplicating', 'Starting deduplication...', 0, {'removed': 0, 'unique': total_frames})
            cleaned_frames_paths = deduplicate_frames_intelligent(
                extracted_frames_paths,
                phash_threshold=7,
                ssim_threshold=0.97,
                progress_callback=lambda removed, unique, pct: update_progress(
                    'deduplicating',
                    'Removing duplicate frames...',
                    pct,
                    {'removed': removed, 'unique': unique},
                ),
                cancel_check=cancelled,
            )
            update_progress('deduplicating', f'Removed {len(extracted_frames_paths) - len(cleaned_frames_paths)} duplicate frames', 100, {'removed': len(extracted_frames_paths) - len(cleaned_frames_paths), 'unique': len(cleaned_frames_paths)})
        else:
            update_progress('deduplicating', 'Deduplication skipped', 100, {'skipped': True})

        if cancelled():
            cleanup_job_directories(job_id)
            return None, None, "Processing cancelled by user"

        if not cleaned_frames_paths:
            error_msg = "No unique frames remaining after deduplication"
            logger.error(error_msg)
            update_progress('error', error_msg, 0)
            cleanup_job_directories(job_id)
            return None, None, error_msg

        # Apply timestamps if enabled
        if timestamp_enabled:
            total_ts = len(cleaned_frames_paths)
            def _ts_progress(c, t):
                update_progress('timestamps', 'Adding timestamp to frames...', int(c / t * 100), {'current': c, 'total': t})

            # ── Build exact time map BEFORE dedup (preserves original extraction times) ──
            # Maps each extracted frame path → its exact timestamp in seconds.
            # For Scene Detection: from ffmpeg showinfo PTS output
            # For Time Interval: from frame index × interval
            # Building this BEFORE dedup ensures we capture the original times.
            # After dedup, we filter to only the cleaned frames.
            time_map = None
            if extraction_method == "Scene Detection" and extracted_pts_times is not None:
                if len(extracted_pts_times) == len(extracted_frames_paths):
                    time_map = dict(zip(extracted_frames_paths, extracted_pts_times))
                    logger.info(f"Built time_map with {len(time_map)} exact PTS timestamps from ffmpeg showinfo")
            elif extraction_method == "Time Interval":
                # Pre-compute exact times before dedup preserves them through dedup filtering
                time_map = {
                    fp: i * float(time_interval)
                    for i, fp in enumerate(extracted_frames_paths)
                }

            # Filter time_map to only frames that survived dedup
            if time_map:
                time_map = {fp: time_map[fp] for fp in cleaned_frames_paths if fp in time_map}
                if time_map:
                    logger.info(f"Preserved exact timestamps for {len(time_map)}/{total_ts} frames after dedup")

            apply_timestamps_to_frames(
                cleaned_frames_paths,
                extraction_method,
                time_interval,
                duration,
                progress_callback=_ts_progress,
                pts_map=time_map,
            )
            update_progress('timestamps', 'Timestamp added', 100, {'current': total_ts, 'total': total_ts})

        # Compress frames if enabled (before building output)
        if compress_enabled:
            from .compress import compress_frames
            update_progress('compressing', 'Compressing frames…', 0, {'current': 0, 'total': len(cleaned_frames_paths)})
            compress_frames(
                cleaned_frames_paths,
                quality=compress_quality,
                progress_callback=lambda c, t: update_progress(
                    'compressing', 'Compressing frames...', int(c / t * 100), {'current': c, 'total': t}
                ),
            )
            update_progress('compressing', 'Frames compressed', 100, {'current': len(cleaned_frames_paths), 'total': len(cleaned_frames_paths)})

        # Build video_info_dict for info page
        video_info_dict = {
            'title': video_title,
            'url': url,
            'duration': duration,
            'thumbnail_url': thumbnail_url,
        }

        # Generate output file
        fmt_label = output_format.upper()

        def _build_progress(pct, msg=''):
            details = {'format': fmt_label}
            # Parse "Adding page X/Y" or "Adding slide X/Y" for frame progress
            m = re.search(r'(?:page|slide)\s+(\d+)/(\d+)', msg)
            if m:
                details['current_frame'] = int(m.group(1))
                details['total_frames'] = int(m.group(2))
            update_progress('building', msg or f'Building {fmt_label}…', pct, details)

        output_path = None
        if output_format == "pdf":
            output_path = convert_frames_to_pdf(
                cleaned_frames_paths, job_output_dir, output_filename_base,
                video_info_dict=video_info_dict, output_format=output_format,
                total_frames=len(cleaned_frames_paths),
                extraction_method=extraction_method, quality=quality,
                compress_enabled=compress_enabled,
                compress_quality=compress_quality,
                actual_quality=actual_quality,
                progress_callback=_build_progress,
            )
        else:
            output_path = convert_frames_to_ppt(
                cleaned_frames_paths, job_output_dir, output_filename_base,
                video_info_dict=video_info_dict, output_format=output_format,
                total_frames=len(cleaned_frames_paths),
                extraction_method=extraction_method, quality=quality,
                compress_enabled=compress_enabled,
                compress_quality=compress_quality,
                actual_quality=actual_quality,
                progress_callback=_build_progress,
            )

        # Remove job temp directories (frames + downloads) after successful build
        cleanup_job_directories(job_id)

        if not output_path:
            error_msg = "Failed to generate output file"
            logger.error(error_msg)
            update_progress('error', error_msg, 0)
            return None, None, error_msg

        update_progress('building', 'Done', 100)
        save_output_meta(
            job_output_dir,
            os.path.basename(output_path),
            video_title=video_title,
            job_id=job_id,
        )
        update_progress('complete', 'Processing complete!', 100)
        return output_path, video_title, None

    except Exception as e:
        error_msg = f"Error processing video: {str(e)}"
        logger.error(error_msg)
        try:
            cleanup_job_directories(job_id)
        except Exception:
            pass
        return None, None, error_msg


def process_main_url(url, output_format, extraction_method, time_interval, quality,                      job_id, deduplication_enabled=True, timestamp_enabled=False, compress_enabled=False,
                      compress_quality=85,
                      progress_callback=None, playlist_output_dir=None, url_type=None):
    """
    Determines if URL is single video or playlist and processes accordingly.
    
    Args:
        url: YouTube video or playlist URL
        output_format: Either 'pdf' or 'pptx'
        extraction_method: Either 'Scene Detection' or 'Time Interval'
        time_interval: Time interval in seconds (for Time Interval method)
        quality: Video quality (e.g., '480p')
        job_id: Unique job identifier
        deduplication_enabled: Whether to enable frame deduplication
        timestamp_enabled: Whether to add timestamps to frames
        compress_enabled: Whether to re-compress frames before building output
        compress_quality: JPEG quality for compression (1-100, higher = better)
        progress_callback: Optional callback function to report progress (stage, message, progress)
        url_type: 'single', 'playlist', or None (auto-detect via yt-dlp)
    
    Returns:
        Tuple of (output_paths, video_titles, error_message)
        output_paths: List of output file paths
        video_titles: List of video titles
        error_message: Error message if any
    """
    logger.info("\n" + "=" * 70 + "\nPROCESSING STARTED\n" + "=" * 70)

    if not url_type:
        url_type, _ = parse_youtube_url(url)

    if url_type == 'single':
        urls_to_process = [url]
        playlist_title = None
    else:
        urls_to_process, playlist_title = get_playlist_videos(url)

    if not urls_to_process:
        error_msg = "Could not extract any video URLs from the provided link. Please check the URL and try again."
        logger.error(error_msg)
        logger.info("\n" + "=" * 70 + "\nPROCESSING COMPLETED\n" + "=" * 70)
        return [], [], error_msg

    output_paths = []
    video_titles = []

    if len(urls_to_process) == 1:
        output_path, video_title, error = process_video(
            urls_to_process[0], output_format, extraction_method, float(time_interval),
            quality, job_id, deduplication_enabled, timestamp_enabled, compress_enabled,
            compress_quality=compress_quality,
            progress_callback=progress_callback, target_output_dir=playlist_output_dir,
        )
        if output_path:
            output_paths.append(output_path)
            video_titles.append(video_title)
        return output_paths, video_titles, error
    else:
        # Process playlist
        total_videos = len(urls_to_process)

        # Send initial playlist info immediately
        if progress_callback:
            progress_callback(
                'playlist',
                f'Playlist: {total_videos} videos',
                0, None,
                {'total': total_videos, 'completed': 0, 'remaining': total_videos},
            )

        # Create playlist-named subfolder for output with timestamp
        from config import OUTPUT_DIR
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        safe_playlist_title = re.sub(r'[^a-zA-Z0-9 _-]', '', playlist_title or 'Playlist').strip() or 'Playlist'
        safe_playlist_title = safe_playlist_title[:80]  # limit length (reserve space for timestamp)
        safe_playlist_title = f"{safe_playlist_title} -- {timestamp}"
        playlist_output_dir = os.path.join(OUTPUT_DIR, safe_playlist_title)
        os.makedirs(playlist_output_dir, exist_ok=True)
        logger.info(f"Playlist output folder: {playlist_output_dir}")

        # ── Prefetch metadata ahead ──────────────────────────────────────
        # Start background fetches for the first N videos so by the time
        # each video is reached in the loop, its metadata is already cached.
        # The prefetch runs concurrently with first-video processing, saving
        # ~5-10s per subsequent video.
        def _prefetch_one(video_url):
            """Start a background thread to fetch & cache metadata for a URL."""
            if is_cancelled(job_id):
                return None
            def _do_fetch():
                from .youtube_downloader import fetch_video_metadata
                meta, full_info, clients = fetch_video_metadata(video_url)
                with _prefetch_lock:
                    _prefetch_cache[video_url] = (meta, full_info, clients)
            t = threading.Thread(target=_do_fetch, daemon=True)
            t.start()
            return t

        # Prefetch the first two videos upfront (so video 0 and 1 have a head start)
        _prefetch_one(urls_to_process[0])
        if total_videos > 1:
            _prefetch_one(urls_to_process[1])

        for i, video_url in enumerate(urls_to_process):
            if is_cancelled(job_id):
                # Clean up any sub-job temp dirs that may not have been cleaned
                cleanup_job_directories(job_id)
                from config import FRAMES_DIR, TEMP_DOWNLOAD_DIR
                for vid_idx in range(1, total_videos + 1):
                    cleanup_job_directories(f"{job_id}_video_{vid_idx}")
                return output_paths, video_titles, "Processing cancelled by user"

            sub_job_id = f"{job_id}_video_{i+1}"
            completed = i
            remaining = total_videos - i - 1

            # Send playlist info update
            if progress_callback:
                progress_callback(
                    'playlist',
                    f'Processing video {i + 1}/{total_videos}',
                    0,
                    None,
                    {
                        'total': total_videos,
                        'completed': completed,
                        'remaining': remaining,
                    },
                )

            # Try to retrieve prefetched metadata from cache
            with _prefetch_lock:
                cached = _prefetch_cache.pop(video_url, None)

            output_path, video_title, error = process_video(
                video_url, output_format, extraction_method, float(time_interval),
                quality, sub_job_id, deduplication_enabled, timestamp_enabled, compress_enabled,
                compress_quality=compress_quality,
                progress_callback=progress_callback, target_output_dir=playlist_output_dir,
                prefetched_metadata=cached,
            )
            if output_path:
                output_paths.append(output_path)
                video_titles.append(video_title)
            else:
                logger.warning(f"Failed to process video {i+1}/{len(urls_to_process)}: {error}")

            # Prefetch the next-next video (i+2) while current is processing —
            # by the time we reach it, metadata will likely be cached.
            next_idx = i + 2
            if next_idx < total_videos:
                _prefetch_one(urls_to_process[next_idx])

        logger.info("\n" + "=" * 70 + "\nPROCESSING COMPLETED\n" + "=" * 70)

        return output_paths, video_titles, None
