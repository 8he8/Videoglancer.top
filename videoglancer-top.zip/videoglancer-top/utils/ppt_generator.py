"""
PowerPoint generator module using python-pptx.
Images are placed at their native aspect ratio (no distortion),
centered on each slide — like the PDF generator preserves dimensions.
"""

import os
import io
import logging
from PIL import Image
from pptx import Presentation
from pptx.util import Inches

logger = logging.getLogger(__name__)


def _scale_and_center(slide_w, slide_h, img_w, img_h):
    """Return (left_emu, top_emu, width_emu, height_emu) to fit
    an image of (img_w, img_h) pixels centered within a slide of
    (slide_w, slide_h) EMU while preserving aspect ratio."""
    scale = min(slide_w / img_w, slide_h / img_h)
    disp_w = int(img_w * scale)
    disp_h = int(img_h * scale)
    left = (slide_w - disp_w) // 2
    top = (slide_h - disp_h) // 2
    return left, top, disp_w, disp_h


def _add_image_centered(slide, img_src, slide_w_emu, slide_h_emu):
    """Add an image (PIL Image or file path) to slide centered with aspect ratio preserved."""
    if isinstance(img_src, Image.Image):
        buf = io.BytesIO()
        img_src.save(buf, "PNG")
        buf.seek(0)
        w, h = img_src.size
        left, top, dw, dh = _scale_and_center(slide_w_emu, slide_h_emu, w, h)
        return slide.shapes.add_picture(buf, left, top, dw, dh)
    else:
        with Image.open(img_src) as img:
            w, h = img.size
        left, top, dw, dh = _scale_and_center(slide_w_emu, slide_h_emu, w, h)
        return slide.shapes.add_picture(img_src, left, top, dw, dh)


def convert_frames_to_ppt(frame_paths_list, target_output_dir, output_filename_base,
                           video_info_dict=None, output_format="pptx",
                           total_frames=0, extraction_method="", quality="",
                           compress_enabled=False, compress_quality=None,
                           progress_callback=None):
    """
    Convert extracted frames to PowerPoint.
    Prepends a YouTube-style info page as slide 1.
    Reports smooth progress via progress_callback(pct, message).

    Images are placed at their native aspect ratio (no distortion)
    and centered on each slide.

    Args:
        frame_paths_list: List of paths to frame images
        target_output_dir: Directory to save the PowerPoint
        output_filename_base: Base name for the output file
        video_info_dict: Dictionary containing video metadata
        output_format: Format type (should be "pptx")
        total_frames: Number of frames
        extraction_method: Method used for frame extraction
        quality: Video quality downloaded
        progress_callback: Optional callback(pct, msg) for progress updates

    Returns:
        Path to the generated PowerPoint file, or None on failure
    """
    logger.info("\n" + "=" * 70 + "\nCREATING POWERPOINT\n" + "=" * 70)

    if not frame_paths_list:
        logger.error("Error: No frames found to convert to PowerPoint.")
        return None

    def _progress(pct, msg=''):
        if progress_callback:
            progress_callback(pct, msg)
        logger.info(f"[PPT BUILD] {pct}% - {msg}")

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    slide_w_emu = prs.slide_width
    slide_h_emu = prs.slide_height

    # --- Info page slide ---
    _progress(5, 'Generating info page…')
    if video_info_dict:
        try:
            from .info_page_generator import create_info_page_image
            frame_w, frame_h = None, None
            if frame_paths_list:
                try:
                    first_frame = Image.open(frame_paths_list[0])
                    frame_w, frame_h = first_frame.size
                    logger.info(f"Detected frame size: {frame_w}x{frame_h}")
                except Exception as e:
                    logger.warning(f"Could not read frame dimensions: {e}")
            info_img, link_regions = create_info_page_image(
                video_info_dict, output_format,
                total_frames, extraction_method, quality,
                page_width=frame_w, page_height=frame_h,
                compress_enabled=compress_enabled,
                compress_quality=compress_quality,
            )
            info_page_w, info_page_h = info_img.size
            info_slide = prs.slides.add_slide(prs.slide_layouts[6])
            _add_image_centered(info_slide, info_img, slide_w_emu, slide_h_emu)

            # --- Add clickable hyperlinks on the info page slide ---
            if link_regions and info_page_w and info_page_h:
                from pptx.enum.shapes import MSO_SHAPE
                scale = min(slide_w_emu / info_page_w, slide_h_emu / info_page_h)
                for x0, y0, x1, y1, url in link_regions:
                    left = int((x0 * scale) + (slide_w_emu - info_page_w * scale) // 2)
                    top = int((y0 * scale) + (slide_h_emu - info_page_h * scale) // 2)
                    width = int((x1 - x0) * scale)
                    height = int((y1 - y0) * scale)
                    shape = info_slide.shapes.add_shape(
                        MSO_SHAPE.RECTANGLE, left, top, width, height
                    )
                    shape.fill.background()
                    shape.line.fill.background()
                    shape.click_action.hyperlink.address = url
                logger.info(f"Added {len(link_regions)} clickable hyperlink(s) to info page slide.")

            logger.info("Info page slide added.")
        except Exception as e:
            logger.warning(f"WARNING: Could not add info page slide: {e}")
    else:
        link_regions = []

    _progress(10, 'Info page ready')

    # --- Frame slides ---
    logger.info(f"Total frames: {len(frame_paths_list)}")
    logger.info(f"Adding frames to PowerPoint slides (native aspect ratio preserved)...")

    total = len(frame_paths_list)
    report_every = max(1, total // 50)

    for i, frame_path in enumerate(frame_paths_list):
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        _add_image_centered(slide, frame_path, slide_w_emu, slide_h_emu)
        if (i + 1) % report_every == 0 or i == total - 1:
            pct = 10 + int((i + 1) / total * 85)
            _progress(pct, f'Adding slide {i+1}/{total}')

    os.makedirs(target_output_dir, exist_ok=True)
    output_path = os.path.join(target_output_dir, output_filename_base)

    _progress(96, 'Writing PowerPoint file…')
    prs.save(output_path)

    file_size = os.path.getsize(output_path) / (1024*1024)
    logger.info(f"PowerPoint created: {output_filename_base}")
    logger.info(f"File size: {file_size:.2f} MB")
    logger.info(f"Location: {output_path}")
    _progress(100, 'Done')
    logger.info("=" * 70)
    return output_path
