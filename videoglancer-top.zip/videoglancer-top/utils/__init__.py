"""
Utility modules for Videoglancer Flask application.
"""

from .youtube_downloader import (
    download_video_file,
    get_playlist_videos,
    get_quality_format,
    format_youtube_time,
    parse_youtube_url
)
from .frame_extractor import (
    extract_frames_time_interval,
    extract_frames_scene_detection
)
from .deduplicator import deduplicate_frames_intelligent
from .timestamp_overlay import add_timestamp_to_frame, apply_timestamps_to_frames
from .info_page_generator import create_info_page_image, fetch_image_bytes
from .pdf_generator import convert_frames_to_pdf
from .ppt_generator import convert_frames_to_ppt
from .file_manager import setup_directories, cleanup_temp_files
from .pipeline import process_video, process_main_url

__all__ = [
    'download_video_file',
    'get_playlist_videos',
    'get_quality_format',
    'format_youtube_time',
    'parse_youtube_url',
    'extract_frames_time_interval',
    'extract_frames_scene_detection',
    'deduplicate_frames_intelligent',
    'add_timestamp_to_frame',
    'apply_timestamps_to_frames',
    'create_info_page_image',
    'fetch_image_bytes',
    'convert_frames_to_pdf',
    'convert_frames_to_ppt',
    'setup_directories',
    'cleanup_temp_files',
    'process_video',
    'process_main_url'
]
