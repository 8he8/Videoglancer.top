"""
Timestamp overlay module for adding YouTube-style timestamps to frames.
Extracted from the original Colab notebook.
"""

import os
import logging
from PIL import Image, ImageDraw, ImageFont
from config import FONT_PATHS

logger = logging.getLogger(__name__)


def _load_font(size, bold=True):
    """Load a font at the given size from available font paths."""
    paths = FONT_PATHS['bold'] if bold else FONT_PATHS['regular']
    for fp in paths:
        if os.path.exists(fp):
            try:
                return ImageFont.truetype(fp, size)
            except Exception:
                continue
    return ImageFont.load_default()


def add_timestamp_to_frame(frame_path, timestamp_str):
    """
    Adds a YouTube-style timestamp overlay to a frame image.

    Font size is proportional to frame height but clamped (10-18px) so the
    timestamp is readable at every resolution without being tiny at 144p
    or huge at 720p. The background is a rounded-rectangle with
    semi-transparent black fill so the video frame is visible behind the
    badge. Padding, margin, and corner radius scale slightly with the
    font size but stay within tight bounds.

    Args:
        frame_path: Path to the frame image file
        timestamp_str: Timestamp string in format "hh:mm:ss" or "mm:ss" or "0:ss"
    """
    try:
        img = Image.open(frame_path).convert("RGBA")

        img_h = img.size[1]

        # ── Proportional font size, clamped to a reasonable range ──
        # Grows gently with resolution: ~10px at 144p, 16px at 360p, 18px at 720p
        # Not wildly variable (9→36 like original) and not flat (13px everywhere)
        font_size = max(10, min(18, int(img_h * 0.045)))
        font = _load_font(font_size, bold=True)
        if font is None:
            font = ImageFont.load_default()

        draw = ImageDraw.Draw(img)

        # Measure text bounds
        bbox = draw.textbbox((0, 0), timestamp_str, font=font)
        text_w = bbox[2] - bbox[0]
        text_h = bbox[3] - bbox[1]

        # ── Minimal padding (scales slightly with font size) ──
        pad_h = max(3, min(6, int(font_size * 0.35)))
        pad_v = max(2, min(4, int(font_size * 0.25)))
        margin = max(3, min(8, int(img_h * 0.015)))
        radius = max(2, min(5, int(font_size * 0.25)))

        # Bottom-right position
        box_x2 = img.size[0] - margin
        box_y2 = img.size[1] - margin
        box_x1 = box_x2 - text_w - pad_h * 2
        box_y1 = box_y2 - text_h - pad_v * 2

        # ── Semi-transparent black background ──
        # Alpha = 170 / 255 ≈ 67% opacity — frame visible behind the badge
        overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
        overlay_draw = ImageDraw.Draw(overlay)

        overlay_draw.rounded_rectangle(
            [box_x1, box_y1, box_x2, box_y2],
            radius=radius,
            fill=(0, 0, 0, 170)
        )

        # Center text within the box, accounting for bbox offset
        cx = (box_x1 + box_x2) // 2
        cy = (box_y1 + box_y2) // 2
        text_cx = bbox[0] + text_w // 2
        text_cy = bbox[1] + text_h // 2
        tx = cx - text_cx
        ty = cy - text_cy

        # Opaque white text on the overlay
        overlay_draw.text((tx, ty), timestamp_str, font=font, fill=(255, 255, 255, 255))

        # Composite overlay onto the frame and convert back to RGB for JPEG save
        img = Image.alpha_composite(img, overlay).convert("RGB")
        img.save(frame_path, "JPEG", quality=95)

    except Exception as e:
        logger.warning(f"WARNING: Could not add timestamp to {frame_path}: {e}")


def apply_timestamps_to_frames(frame_paths, extraction_method, interval_seconds, duration, progress_callback=None, pts_map=None):
    """
    Applies YouTube-style timestamps to each frame based on when it was extracted.
    For Time Interval: frame index * interval_seconds.
    For Scene Detection: uses exact PTS timestamps from ffmpeg if available,
                         otherwise evenly distributed across duration (fallback).
    Modifies frames in-place.
    
    Args:
        frame_paths: List of paths to frame images
        extraction_method: Either "Time Interval" or "Scene Detection"
        interval_seconds: Time interval in seconds (for Time Interval method)
        duration: Total video duration in seconds
        progress_callback: Optional (current, total) called per frame
        pts_map: Optional dict mapping frame_path -> exact PTS timestamp in seconds
                 (for Scene Detection with showinfo capture)
    """
    from .youtube_downloader import format_youtube_time
    
    logger.info("\n" + "=" * 70 + "\nAPPLYING TIMESTAMPS TO FRAMES\n" + "=" * 70)
    total = len(frame_paths)
    for i, fp in enumerate(frame_paths):
        if extraction_method == "Time Interval":
            frame_time = i * interval_seconds
        else:
            # Use exact PTS if available (from ffmpeg showinfo)
            if pts_map and fp in pts_map:
                frame_time = int(round(pts_map[fp]))
            elif total > 1:
                frame_time = int((i / (total - 1)) * duration)
            else:
                frame_time = 0
        ts_str = format_youtube_time(int(frame_time))
        add_timestamp_to_frame(fp, ts_str)
        if progress_callback:
            progress_callback(i + 1, total)
        if i % 20 == 0 or i == total - 1:
            logger.info(f"  Stamped {i+1}/{total}: {fp} @ {ts_str}")
    logger.info(f"Timestamps applied to {total} frames.")
    logger.info("=" * 70)
