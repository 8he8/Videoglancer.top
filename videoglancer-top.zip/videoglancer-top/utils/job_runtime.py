"""Job cancellation and subprocess tracking for immediate stop."""

import logging
import subprocess

logger = logging.getLogger(__name__)

_cancelled_jobs = set()
_active_processes = {}


def mark_cancelled(job_id):
    """Mark job cancelled and terminate running subprocesses."""
    _cancelled_jobs.add(job_id)
    terminate_job_processes(job_id)
    logger.info(f"Job {job_id} marked cancelled, subprocesses terminated")


def is_cancelled(job_id):
    return job_id in _cancelled_jobs


def clear_cancelled(job_id):
    _cancelled_jobs.discard(job_id)


def register_process(job_id, process):
    if job_id not in _active_processes:
        _active_processes[job_id] = []
    _active_processes[job_id].append(process)


def terminate_job_processes(job_id):
    """Terminate all registered subprocesses for a job."""
    for proc in _active_processes.get(job_id, []):
        try:
            if proc.poll() is None:
                proc.terminate()
                proc.wait(timeout=3)
        except Exception as e:
            logger.warning(f"Failed to terminate process for {job_id}: {e}")
    _active_processes[job_id] = []
