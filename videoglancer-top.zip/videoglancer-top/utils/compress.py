"""
Frame-level compression module.
Re-compresses extracted JPEG frames to reduce file size before building PDF/PPTX.
Also strips EXIF metadata from the JPEGs.
"""

import os
import io
import logging
from PIL import Image

logger = logging.getLogger(__name__)

JPEG_QUALITY = 85


def compress_frames(frame_paths, quality=JPEG_QUALITY, progress_callback=None):
    """
    Re-compress each JPEG frame in-place at the given quality and strip metadata.

    Args:
        frame_paths: List of paths to frame image files
        quality: JPEG quality (1-100, higher = better)
        progress_callback: Optional (current, total)

    Returns:
        int: Number of frames compressed
    """
    total = len(frame_paths)
    count = 0
    for i, fp in enumerate(frame_paths):
        try:
            img = Image.open(fp)
            img.save(fp, "JPEG", quality=quality, optimize=True)
            count += 1
        except Exception as e:
            logger.warning(f"Failed to compress {fp}: {e}")
        if progress_callback:
            progress_callback(i + 1, total)
    logger.info(f"Compressed {count}/{total} frames at quality {quality}")
    return count
