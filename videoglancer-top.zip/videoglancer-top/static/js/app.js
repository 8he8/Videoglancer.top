/**
 * Videoglancer.top - Main JavaScript
 */

// Custom confirmation dialog
function showConfirmDialog(title, description) {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.className = 'confirm-overlay';
        overlay.innerHTML = `
            <div class="confirm-dialog">
                <div class="confirm-content">
                    <div class="confirm-header">
                        <p class="confirm-title">${title}</p>
                    </div>
                    ${description ? `<p class="confirm-desc">${description}</p>` : ''}
                    <div class="confirm-actions">
                        <button class="btn btn-secondary btn-sm confirm-cancel">Cancel</button>
                        <button class="btn btn-danger btn-sm confirm-ok">OK</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        
        const okBtn = overlay.querySelector('.confirm-ok');
        const cancelBtn = overlay.querySelector('.confirm-cancel');
        
        okBtn.addEventListener('click', () => {
            document.body.removeChild(overlay);
            resolve(true);
        });
        
        cancelBtn.addEventListener('click', () => {
            document.body.removeChild(overlay);
            resolve(false);
        });
        
        // Close on overlay click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                document.body.removeChild(overlay);
                resolve(false);
            }
        });
    });
}

// Client-side validation and interactions
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const form = document.getElementById('conversionForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const urlInput = document.getElementById('url');
            const url = urlInput.value.trim();
            
            if (!url) {
                e.preventDefault();
                alert('Please enter a YouTube URL');
                return false;
            }
            
            // Basic URL validation
            if (!url.includes('youtube.com') && !url.includes('youtu.be')) {
                e.preventDefault();
                alert('Please enter a valid YouTube URL');
                return false;
            }
            
            return true;
        });
    }
    
});

// ── Global Toast Utility ────────────────────────────────
window.showToast = function (message, type) {
  var container = document.getElementById("toastContainer");
  if (!container) return;
  container.hidden = false;
  var toast = document.createElement("div");
  toast.className = "toast toast--" + (type || "info");
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(function () {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.3s";
    setTimeout(function () { toast.remove(); }, 300);
  }, 4000);
};

// Utility functions
function formatFileSize(bytes) {
    if (typeof bytes !== 'number' || !isFinite(bytes) || bytes <= 0) return '0 B';
    var units = ['B', 'KB', 'MB', 'GB', 'TB'];
    var i = 0;
    var size = bytes;
    while (size >= 1024 && i < units.length - 1) {
      size /= 1024;
      i++;
    }
    return size.toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
}

function formatTime(seconds) {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hrs > 0) {
        return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else if (mins > 0) {
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    } else {
        return `0:${secs.toString().padStart(2, '0')}`;
    }
}
